package com.tutorialsee.cart;

import java.math.BigDecimal;

public interface Saleable {
	
	public BigDecimal getPrice1();
	
	public String getName1();
	
}
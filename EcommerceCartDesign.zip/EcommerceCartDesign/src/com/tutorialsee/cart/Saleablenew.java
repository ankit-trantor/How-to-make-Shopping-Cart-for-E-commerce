package com.tutorialsee.cart;

import java.math.BigDecimal;

public interface Saleablenew {
	
	public BigDecimal getPrice1();
	
	public String getName1();
}